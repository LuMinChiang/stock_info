import datetime
from .DB import *
# Create your views here.


def trans_date_to_milli_timestamp(date_time):
	tmp_time = date_time.strftime("%Y-%m-%d")
	# print(tmp_time)
	tmp_time = datetime.datetime.strptime(tmp_time,"%Y-%m-%d")
	# print(tmp_time)
	return tmp_time.timestamp()*1000

def get_from_db(data_time):
	db, db_cursor = connect_db(db_name="STOCK_INFO")
	db_cursor = db.cursor(dictionary=True)
	query = "SELECT\
			    g.company_code,\
			    g.data_date\
			FROM\
			    gain_over_3_5 g\
			INNER JOIN\
			    monthly_avg_volume_over_2x m ON g.company_code = m.company_code AND g.data_date = m.data_date\
			INNER JOIN\
			    over_100MA o ON g.company_code = o.company_code AND g.data_date = o.data_date\
			WHERE g.data_date = \""+str(data_time.strftime('%Y-%m-%d'))+"\";"

	db_cursor.execute(query)
	result = db_cursor.fetchall()
	print(query)
	return result
