/**
 * @license Highstock JS v11.3.0 (2024-01-10)
 * @module highcharts/highstock
 *
 * (c) 2009-2024 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import Highcharts from './highcharts.src.js';
import './modules/stock.src.js';
Highcharts.product = 'Highstock';
export default Highcharts;
